(function () {
  'use strict';

  var cfg = window.SSL_CONFIG || {};
  var validators = window.SSLValidators;
  var i18n = window.SSL_I18N || {};

  function getBasePrefix() {
    var scripts = document.querySelectorAll('script[src*="assets/js/main.js"]');
    for (var i = 0; i < scripts.length; i++) {
      var src = scripts[i].getAttribute('src') || '';
      if (src.indexOf('../') === 0) {
        return '../';
      }
    }
    return '';
  }

  var BASE_PREFIX = getBasePrefix();

  function getStoredPref(key, fallback) {
    try {
      var val = window.localStorage.getItem(key);
      return val || fallback;
    } catch (e) {
      return fallback;
    }
  }

  function setStoredPref(key, val) {
    try {
      window.localStorage.setItem(key, val);
    } catch (e) {
      /* localStorage may be unavailable in restricted contexts */
    }
  }

  function hydrateContacts() {
    if (cfg.phoneHref) {
      document.querySelectorAll('[data-tel]').forEach(function (el) {
        el.setAttribute('href', cfg.phoneHref);
      });
    }
    if (cfg.phoneDisplay) {
      document.querySelectorAll('[data-tel-text]').forEach(function (el) {
        el.textContent = cfg.phoneDisplay;
      });
    }
    if (cfg.telegramUrl) {
      document.querySelectorAll('[data-tg]').forEach(function (el) {
        el.setAttribute('href', cfg.telegramUrl);
      });
    }
    var yrEl = document.getElementById('yr');
    if (yrEl) {
      yrEl.textContent = String(new Date().getFullYear());
    }
  }

  /* ========================================================================
     Theme & Language Preferences Engine
     ======================================================================== */

  var currentTheme = validators ? validators.normalizeTheme(getStoredPref('ssl_theme', 'light')) : 'light';
  var currentLang = validators ? validators.normalizeLang(getStoredPref('ssl_lang', 'ru')) : 'ru';

  function updateThemeIcons(theme) {
    document.querySelectorAll('[data-theme-icon]').forEach(function (svg) {
      if (theme === 'dark') {
        svg.innerHTML = '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>';
      } else {
        svg.innerHTML = '<path d="M21 12.79A9 9 0 1 1 11.21 3a7 7 0 0 0 9.79 9.79z"/>';
      }
    });
  }

  function applyTheme(theme) {
    currentTheme = validators ? validators.normalizeTheme(theme) : (theme === 'dark' ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', currentTheme);
    setStoredPref('ssl_theme', currentTheme);
    updateThemeIcons(currentTheme);

    document.querySelectorAll('[data-theme-set]').forEach(function (btn) {
      var active = btn.getAttribute('data-theme-set') === currentTheme;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
  }

  function applyLang(lang) {
    currentLang = validators ? validators.normalizeLang(lang) : 'ru';
    document.documentElement.setAttribute('lang', currentLang);
    setStoredPref('ssl_lang', currentLang);

    var dict = i18n[currentLang] || i18n.ru || {};
    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      var key = el.getAttribute('data-i18n');
      if (dict[key]) {
        el.textContent = dict[key];
      }
    });

    document.querySelectorAll('[data-lang-set]').forEach(function (btn) {
      var active = btn.getAttribute('data-lang-set') === currentLang;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
  }

  function initPreferences() {
    applyTheme(currentTheme);
    applyLang(currentLang);

    document.addEventListener('click', function (e) {
      var toggleBtn = e.target.closest('[data-theme-toggle]');
      if (toggleBtn) {
        applyTheme(currentTheme === 'dark' ? 'light' : 'dark');
        return;
      }

      var themeSetBtn = e.target.closest('[data-theme-set]');
      if (themeSetBtn) {
        applyTheme(themeSetBtn.getAttribute('data-theme-set'));
        return;
      }

      var langSetBtn = e.target.closest('[data-lang-set]');
      if (langSetBtn) {
        applyLang(langSetBtn.getAttribute('data-lang-set'));
      }
    });
  }

  /* ========================================================================
     Settings Drawer & Auth Modal (Future-Ready Concept UI)
     ======================================================================== */

  function initStudioOverlays() {
    if (document.getElementById('ssl-settings-overlay')) return;

    var cabinetHref = BASE_PREFIX + 'cabinet.html';

    var wrapper = document.createElement('div');
    wrapper.innerHTML = [
      '<div class="ui-overlay settings-overlay" id="ssl-settings-overlay" aria-hidden="true">',
      '  <aside class="settings-drawer" role="dialog" aria-modal="true" aria-labelledby="settings-drawer-title">',
      '    <div class="modal-head">',
      '      <div>',
      '        <h2 id="settings-drawer-title" data-i18n="settings.title">Настройки интерфейса</h2>',
      '        <p class="modal-sub" data-i18n="settings.subtitle">Визуальная концепция персональных настроек будущего портала</p>',
      '      </div>',
      '      <button class="icon-btn" type="button" data-close-overlay aria-label="Закрыть настройки">',
      '        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>',
      '      </button>',
      '    </div>',
      '    <div class="drawer-group">',
      '      <span class="drawer-label" data-i18n="settings.themeHeading">Цветовая тема</span>',
      '      <div class="theme-choice-grid">',
      '        <button class="theme-choice-btn" type="button" data-theme-set="light" aria-pressed="true">',
      '          <span class="theme-swatch theme-swatch-light" aria-hidden="true"></span>',
      '          <strong data-i18n="settings.themeLight">Светлая студия</strong>',
      '        </button>',
      '        <button class="theme-choice-btn" type="button" data-theme-set="dark" aria-pressed="false">',
      '          <span class="theme-swatch theme-swatch-dark" aria-hidden="true"></span>',
      '          <strong data-i18n="settings.themeDark">Тёмный режим</strong>',
      '        </button>',
      '      </div>',
      '    </div>',
      '    <div class="drawer-group">',
      '      <span class="drawer-label" data-i18n="settings.langHeading">Язык интерфейса</span>',
      '      <div class="segmented-row" role="group" aria-label="Выбор языка">',
      '        <button class="segmented-btn" type="button" data-lang-set="ru" aria-pressed="true">Русский</button>',
      '        <button class="segmented-btn" type="button" data-lang-set="uz" aria-pressed="false">O‘zbekcha</button>',
      '        <button class="segmented-btn" type="button" data-lang-set="en" aria-pressed="false">English</button>',
      '      </div>',
      '    </div>',
      '    <div class="drawer-group">',
      '      <span class="drawer-label" data-i18n="settings.notifyHeading">Уведомления по проектам (демо)</span>',
      '      <div class="toggle-list">',
      '        <label class="toggle-item"><span>Уведомления в Telegram по SLA</span><input type="checkbox" checked></label>',
      '        <label class="toggle-item"><span>Отчёт по этапам раз в неделю</span><input type="checkbox" checked></label>',
      '        <label class="toggle-item"><span>Счета и акты сверки на e-mail</span><input type="checkbox"></label>',
      '      </div>',
      '    </div>',
      '    <div class="drawer-group">',
      '      <span class="drawer-label" data-i18n="settings.portalHeading">Личный кабинет клиента</span>',
      '      <div class="auth-actions">',
      '        <a class="btn btn-primary" href="' + cabinetHref + '" data-i18n="settings.openCabinet">Открыть макет кабинета</a>',
      '        <button class="btn btn-secondary" type="button" data-open-auth data-i18n="settings.openAuth">Окно авторизации</button>',
      '      </div>',
      '    </div>',
      '  </aside>',
      '</div>',
      '<div class="ui-overlay auth-overlay" id="ssl-auth-overlay" aria-hidden="true">',
      '  <div class="auth-dialog" role="dialog" aria-modal="true" aria-labelledby="auth-modal-title">',
      '    <div class="modal-head">',
      '      <div>',
      '        <h2 id="auth-modal-title" data-i18n="auth.title">Вход в кабинет клиента</h2>',
      '        <p class="modal-sub" data-i18n="auth.subtitle">Визуальный прототип будущей авторизации для просмотра проектов, SLA-заявок и актов.</p>',
      '      </div>',
      '      <button class="icon-btn" type="button" data-close-overlay aria-label="Закрыть окно входа">',
      '        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>',
      '      </button>',
      '    </div>',
      '    <div class="auth-tabs" role="tablist">',
      '      <button class="auth-tab is-active" type="button" data-auth-mode="login" aria-selected="true" data-i18n="auth.tabLogin">Вход</button>',
      '      <button class="auth-tab" type="button" data-auth-mode="register" aria-selected="false" data-i18n="auth.tabRegister">Регистрация</button>',
      '    </div>',
      '    <form id="auth-demo-form" novalidate>',
      '      <div class="auth-field" id="auth-company-wrap" hidden>',
      '        <label for="auth-company">Компания</label>',
      '        <input id="auth-company" type="text" placeholder="ООО «Название компании»">',
      '      </div>',
      '      <div class="auth-field">',
      '        <label for="auth-phone">Телефон или корпоративный E-mail</label>',
      '        <input id="auth-phone" type="text" value="+998 90 601 25 00" placeholder="+998 90 000 00 00">',
      '      </div>',
      '      <div class="auth-field">',
      '        <label for="auth-pass">Код доступа или пароль</label>',
      '        <input id="auth-pass" type="password" value="••••••••" placeholder="Введите пароль">',
      '      </div>',
      '      <div class="auth-actions">',
      '        <button class="btn btn-primary" type="submit" data-i18n="auth.submitDemo">Войти в демо-кабинет</button>',
      '      </div>',
      '    </form>',
      '    <div class="auth-demo-note">',
      '      <a href="' + cabinetHref + '" data-i18n="auth.previewLink">Открыть страницу кабинета без входа →</a>',
      '    </div>',
      '  </div>',
      '</div>'
    ].join('\n');

    document.body.appendChild(wrapper);

    var settingsOverlay = document.getElementById('ssl-settings-overlay');
    var authOverlay = document.getElementById('ssl-auth-overlay');
    var authCompanyWrap = document.getElementById('auth-company-wrap');
    var authForm = document.getElementById('auth-demo-form');

    function closeAllOverlays() {
      settingsOverlay.classList.remove('is-open');
      settingsOverlay.setAttribute('aria-hidden', 'true');
      authOverlay.classList.remove('is-open');
      authOverlay.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('modal-open');
    }

    function openOverlay(overlay) {
      closeAllOverlays();
      overlay.classList.add('is-open');
      overlay.setAttribute('aria-hidden', 'false');
      document.body.classList.add('modal-open');
    }

    document.addEventListener('click', function (e) {
      if (e.target.closest('[data-open-settings]')) {
        e.preventDefault();
        openOverlay(settingsOverlay);
        return;
      }
      if (e.target.closest('[data-open-auth]')) {
        e.preventDefault();
        openOverlay(authOverlay);
        return;
      }
      if (e.target.closest('[data-close-overlay]')) {
        closeAllOverlays();
        return;
      }
      if (e.target === settingsOverlay || e.target === authOverlay) {
        closeAllOverlays();
      }

      var tabBtn = e.target.closest('[data-auth-mode]');
      if (tabBtn) {
        var mode = tabBtn.getAttribute('data-auth-mode');
        authOverlay.querySelectorAll('[data-auth-mode]').forEach(function (t) {
          var isAct = t === tabBtn;
          t.classList.toggle('is-active', isAct);
          t.setAttribute('aria-selected', isAct ? 'true' : 'false');
        });
        if (authCompanyWrap) {
          authCompanyWrap.hidden = mode !== 'register';
        }
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && (settingsOverlay.classList.contains('is-open') || authOverlay.classList.contains('is-open'))) {
        closeAllOverlays();
      }
    });

    if (authForm) {
      authForm.addEventListener('submit', function (e) {
        e.preventDefault();
        window.location.href = cabinetHref;
      });
    }

    applyTheme(currentTheme);
    applyLang(currentLang);
  }

  /* ========================================================================
     Mobile Navigation Drawer
     ======================================================================== */

  function initMobileNav() {
    var burger = document.getElementById('burger');
    var nav = document.getElementById('nav');
    if (!burger || !nav) return;

    function setOpen(isOpen) {
      nav.classList.toggle('is-open', isOpen);
      burger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      burger.setAttribute('aria-label', isOpen ? 'Закрыть меню' : 'Открыть меню');
      document.body.classList.toggle('nav-open', isOpen);
    }

    burger.addEventListener('click', function (e) {
      e.stopPropagation();
      setOpen(!nav.classList.contains('is-open'));
    });

    nav.querySelectorAll('a, button').forEach(function (item) {
      item.addEventListener('click', function () {
        setOpen(false);
      });
    });

    document.addEventListener('click', function (e) {
      if (!nav.classList.contains('is-open')) return;
      if (!nav.contains(e.target) && !burger.contains(e.target)) {
        setOpen(false);
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && nav.classList.contains('is-open')) {
        setOpen(false);
        burger.focus();
      }
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth >= 980 && nav.classList.contains('is-open')) {
        setOpen(false);
      }
    });
  }

  /* ========================================================================
     Hero Architecture Switcher & Home Portal Showcase Tabs
     ======================================================================== */

  function initHeroSwitcher() {
    var container = document.getElementById('hero-switcher');
    if (!container) return;

    var imgEl = document.getElementById('hero-showcase-img');
    var capTitle = document.getElementById('hero-cap-title');
    var capSub = document.getElementById('hero-cap-sub');
    var panelTitle = document.getElementById('hero-panel-title');
    var panelDesc = document.getElementById('hero-panel-desc');
    var panelVal = document.getElementById('hero-panel-val');
    var panelUnit = document.getElementById('hero-panel-unit');

    var presets = {
      studio: {
        img: BASE_PREFIX + 'assets/images/hero-studio.jpg',
        capTitle: 'Инженерный центр Sam Soft Line',
        capSub: 'Комплексная разработка и внедрение в Самарканде',
        title: 'Единый подрядчик для всего IT-контура',
        desc: '1С, веб-порталы, мобильные приложения и поддержка серверов.',
        val: '25+ лет',
        unit: 'на рынке Узбекистана'
      },
      '1c': {
        img: BASE_PREFIX + 'assets/images/service-1c.jpg',
        capTitle: '1С и складская автоматизация',
        capSub: 'Партионный учёт, ТСД и маркировка без простоев',
        title: 'Точность остатков и скорость ревизии',
        desc: 'Синхронизация складов, касс и бухгалтерии в реальном времени.',
        val: '×3,2',
        unit: 'быстрее инвентаризация'
      },
      portal: {
        img: BASE_PREFIX + 'assets/images/service-web.jpg',
        capTitle: 'B2B-порталы и личные кабинеты',
        capSub: 'Прямой обмен ценами, резервами и заказами с 1С',
        title: 'Онлайн-заказы дилеров без звонков',
        desc: 'Персональные прайсы, история отгрузок и мгновенный резерв.',
        val: '4 мин',
        unit: 'оформление заявки'
      },
      mobile: {
        img: BASE_PREFIX + 'assets/images/service-mobile.jpg',
        capTitle: 'Мобильные приложения Android / iOS',
        capSub: 'Офлайн-работа для курьеров, торговых и логистики',
        title: 'Полевая работа без потери накладных',
        desc: 'Маршрутные листы, фотоподтверждение и GPS-трекинг рейсов.',
        val: '100%',
        unit: 'контроль доставки'
      },
      infra: {
        img: BASE_PREFIX + 'assets/images/service-infra.jpg',
        capTitle: 'Серверы, сети и SLA-поддержка',
        capSub: 'Резервное копирование, VPN и защита корпоративных баз',
        title: 'Стабильная работа офиса и филиалов',
        desc: 'Мониторинг серверов 24/7 и выезд инженеров по регламенту.',
        val: '99,8%',
        unit: 'доступность систем'
      }
    };

    var tabs = container.querySelectorAll('[data-hero-tab]');
    tabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        var key = tab.getAttribute('data-hero-tab');
        var data = presets[key];
        if (!data) return;

        tabs.forEach(function (t) {
          var active = t === tab;
          t.classList.toggle('is-active', active);
          t.setAttribute('aria-pressed', active ? 'true' : 'false');
        });

        if (imgEl) imgEl.src = data.img;
        if (capTitle) capTitle.textContent = data.capTitle;
        if (capSub) capSub.textContent = data.capSub;
        if (panelTitle) panelTitle.textContent = data.title;
        if (panelDesc) panelDesc.textContent = data.desc;
        if (panelVal) panelVal.textContent = data.val;
        if (panelUnit) panelUnit.textContent = data.unit;
      });
    });
  }

  function initPortalPreview() {
    var preview = document.getElementById('portal-preview');
    if (!preview) return;

    var tbody = document.getElementById('portal-preview-rows');
    var tabs = preview.querySelectorAll('[data-portal-preview]');

    var rowsByTab = {
      sla: [
        ['SLA-412 · Обновление обмена 1С ↔ B2B', 'В работе', 'state-text-info', '14 мин назад'],
        ['SLA-409 · Настройка ТСД на складе №4', 'Выполнено', 'state-text-ok', 'Сегодня, 11:20'],
        ['SLA-405 · Резервная копия PostgreSQL', 'Запланировано', 'state-text-warn', '18:00']
      ],
      stages: [
        ['Этап 1 · Аудит товарных партий и складов', 'Завершён', 'state-text-ok', '100%'],
        ['Этап 2 · Настройка ТСД и маркировки', 'Активен', 'state-text-info', '78%'],
        ['Этап 3 · Обучение кассиров и запуск', 'Ожидает', 'state-text-warn', '0%']
      ],
      docs: [
        ['Акт №118 · Сопровождение 1С (ноябрь)', 'Подписан', 'state-text-ok', '4 800 000 сум'],
        ['Договор №44-IT · B2B-портал дилеров', 'Активен', 'state-text-info', 'Этап 2/3'],
        ['Счёт №209 · Модернизация сети офиса', 'Оплачен', 'state-text-ok', '6 200 000 сум']
      ]
    };

    tabs.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var key = btn.getAttribute('data-portal-preview');
        var list = rowsByTab[key];
        if (!list || !tbody) return;

        tabs.forEach(function (t) {
          var active = t === btn;
          t.classList.toggle('is-active', active);
          t.setAttribute('aria-pressed', active ? 'true' : 'false');
        });

        tbody.innerHTML = list.map(function (row) {
          return '<tr><td>' + row[0] + '</td><td class="' + row[2] + '">' + row[1] + '</td><td>' + row[3] + '</td></tr>';
        }).join('');
      });
    });
  }

  /* ========================================================================
     Client Cabinet Prototype Page (cabinet.html)
     ======================================================================== */

  function initCabinetPortal() {
    var shell = document.getElementById('cabinet-shell');
    if (!shell) return;

    var navBtns = shell.querySelectorAll('[data-cabinet-view]');
    var views = shell.querySelectorAll('[data-view-panel]');
    var viewTitle = document.getElementById('cabinet-view-title');

    var titles = {
      overview: 'Обзор подключённых систем',
      projects: 'Активные проекты и этапы',
      tickets: 'Заявки и обращения по SLA',
      docs: 'Договоры, акты и счета',
      settings: 'Настройки профиля, темы и языка'
    };

    navBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var view = btn.getAttribute('data-cabinet-view');
        navBtns.forEach(function (b) {
          var act = b === btn;
          b.classList.toggle('is-active', act);
          b.setAttribute('aria-current', act ? 'page' : 'false');
        });
        views.forEach(function (panel) {
          panel.hidden = panel.getAttribute('data-view-panel') !== view;
        });
        if (viewTitle && titles[view]) {
          viewTitle.textContent = titles[view];
        }
      });
    });

    var ticketFilters = document.getElementById('ticket-filters');
    var ticketRows = shell.querySelectorAll('[data-ticket-status]');
    var ticketCount = document.getElementById('ticket-count');
    if (ticketFilters) {
      var filterBtns = ticketFilters.querySelectorAll('[data-ticket-filter]');
      filterBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
          var status = btn.getAttribute('data-ticket-filter');
          var visible = 0;
          ticketRows.forEach(function (row) {
            var match = status === 'all' || row.getAttribute('data-ticket-status') === status;
            row.hidden = !match;
            if (match) visible += 1;
          });
          filterBtns.forEach(function (b) {
            var act = b === btn;
            b.classList.toggle('is-active', act);
            b.setAttribute('aria-pressed', act ? 'true' : 'false');
          });
          if (ticketCount) {
            ticketCount.textContent = 'Показано заявок: ' + visible;
          }
        });
      });
    }
  }

  /* ========================================================================
     Copy Phone, Lead Form, Review Carousel & Project Filters
     ======================================================================== */

  function initCopyButtons() {
    document.querySelectorAll('[data-copy-phone]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var phone = cfg.phoneDisplay || '+998 90 601 25 00';
        var labelEl = btn.querySelector('[data-copy-label]') || btn;
        var original = labelEl.textContent;

        function markCopied() {
          labelEl.textContent = 'Скопировано';
          btn.classList.add('is-copied');
          setTimeout(function () {
            labelEl.textContent = original;
            btn.classList.remove('is-copied');
          }, 2200);
        }

        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(phone).then(markCopied).catch(markCopied);
        } else {
          markCopied();
        }
      });
    });
  }

  function initLeadForm() {
    var form = document.getElementById('lead-form');
    if (!form || !validators) return;

    var nameInput = document.getElementById('lead-name');
    var phoneInput = document.getElementById('lead-phone');
    var taskInput = document.getElementById('lead-task');
    var consentInput = document.getElementById('lead-consent');
    var errName = document.getElementById('err-name');
    var errPhone = document.getElementById('err-phone');
    var errConsent = document.getElementById('err-consent');
    var successBox = document.getElementById('lead-success');
    var successMeta = document.getElementById('lead-success-meta');
    var resetBtn = document.getElementById('lead-reset');

    if (phoneInput) {
      phoneInput.addEventListener('input', function () {
        var raw = phoneInput.value;
        var digits = raw.replace(/\D/g, '');
        if (!digits.length) {
          phoneInput.value = '';
          return;
        }
        phoneInput.value = validators.formatUzPhone(raw);
      });
    }

    function setFieldError(input, errEl, message) {
      if (errEl) {
        errEl.textContent = message;
        errEl.hidden = !message;
      }
      if (input) {
        input.setAttribute('aria-invalid', message ? 'true' : 'false');
        input.classList.toggle('is-invalid', Boolean(message));
      }
    }

    function clearFieldError(input, errEl) {
      setFieldError(input, errEl, '');
    }

    if (nameInput) nameInput.addEventListener('input', function () { clearFieldError(nameInput, errName); });
    if (phoneInput) phoneInput.addEventListener('input', function () { clearFieldError(phoneInput, errPhone); });
    if (consentInput) consentInput.addEventListener('change', function () { clearFieldError(consentInput, errConsent); });

    form.addEventListener('submit', function (e) {
      e.preventDefault();

      var result = validators.validateLeadForm({
        name: nameInput ? nameInput.value : '',
        phone: phoneInput ? phoneInput.value : '',
        consent: consentInput ? consentInput.checked : false
      });

      setFieldError(nameInput, errName, result.errors.name);
      setFieldError(phoneInput, errPhone, result.errors.phone);
      setFieldError(consentInput, errConsent, result.errors.consent);

      if (!result.valid) {
        if (result.errors.name && nameInput) nameInput.focus();
        else if (result.errors.phone && phoneInput) phoneInput.focus();
        else if (result.errors.consent && consentInput) consentInput.focus();
        return;
      }

      if (successMeta) {
        var submittedName = nameInput ? nameInput.value.trim() : '';
        var submittedPhone = phoneInput ? phoneInput.value.trim() : '';
        successMeta.textContent = submittedName + ' · ' + submittedPhone;
      }

      form.hidden = true;
      if (successBox) successBox.hidden = false;
    });

    if (resetBtn) {
      resetBtn.addEventListener('click', function () {
        form.reset();
        clearFieldError(nameInput, errName);
        clearFieldError(phoneInput, errPhone);
        clearFieldError(consentInput, errConsent);
        if (taskInput) taskInput.value = '';
        if (successBox) successBox.hidden = true;
        form.hidden = false;
        if (nameInput) nameInput.focus();
      });
    }
  }

  function initReviewCarousel() {
    var viewport = document.getElementById('review-viewport');
    var track = document.getElementById('review-track');
    var prevBtn = document.getElementById('review-prev');
    var nextBtn = document.getElementById('review-next');
    var statusEl = document.getElementById('review-status');
    var dotsContainer = document.getElementById('review-dots');

    if (!viewport || !track || !validators) return;

    var cards = Array.prototype.slice.call(track.querySelectorAll('.review-card'));
    if (!cards.length) return;

    var currentIndex = 0;

    function getMetrics() {
      var pageSize = validators.getCarouselPageSize(window.innerWidth);
      var maxIndex = Math.max(0, cards.length - pageSize);
      return { pageSize: pageSize, maxIndex: maxIndex };
    }

    function renderDots(maxIndex) {
      if (!dotsContainer) return;
      dotsContainer.innerHTML = '';
      for (var i = 0; i <= maxIndex; i++) {
        (function (idx) {
          var dot = document.createElement('button');
          dot.type = 'button';
          dot.className = 'carousel-dot' + (idx === currentIndex ? ' is-active' : '');
          dot.setAttribute('aria-label', 'Показать позицию ' + (idx + 1));
          dot.setAttribute('aria-pressed', idx === currentIndex ? 'true' : 'false');
          dot.addEventListener('click', function () {
            currentIndex = idx;
            update();
          });
          dotsContainer.appendChild(dot);
        })(i);
      }
    }

    function update() {
      var metrics = getMetrics();
      currentIndex = validators.clampCarouselIndex(currentIndex, cards.length, metrics.pageSize);

      var gap = 24;
      var cardWidth = cards[0].getBoundingClientRect().width;
      var offset = currentIndex * (cardWidth + gap);
      track.style.transform = 'translate3d(' + (-offset) + 'px, 0, 0)';

      if (prevBtn) prevBtn.disabled = currentIndex === 0;
      if (nextBtn) nextBtn.disabled = currentIndex >= metrics.maxIndex;

      if (statusEl) {
        var from = currentIndex + 1;
        var to = Math.min(cards.length, currentIndex + metrics.pageSize);
        statusEl.textContent = metrics.pageSize > 1
          ? from + '–' + to + ' из ' + cards.length
          : from + ' из ' + cards.length;
      }

      renderDots(metrics.maxIndex);
    }

    if (prevBtn) {
      prevBtn.addEventListener('click', function () {
        currentIndex = Math.max(0, currentIndex - 1);
        update();
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', function () {
        var metrics = getMetrics();
        currentIndex = Math.min(metrics.maxIndex, currentIndex + 1);
        update();
      });
    }

    window.addEventListener('resize', update);
    update();
  }

  function initProjectFilters() {
    var filterBar = document.getElementById('project-filters');
    var grid = document.getElementById('project-grid');
    if (!filterBar || !grid) return;

    var buttons = Array.prototype.slice.call(filterBar.querySelectorAll('[data-filter]'));
    var cards = Array.prototype.slice.call(grid.querySelectorAll('[data-category]'));
    var countEl = document.getElementById('project-count');

    function applyFilter(category) {
      var visible = 0;
      cards.forEach(function (card) {
        var match = category === 'all' || card.getAttribute('data-category') === category;
        card.hidden = !match;
        if (match) visible += 1;
      });
      buttons.forEach(function (btn) {
        var active = btn.getAttribute('data-filter') === category;
        btn.classList.toggle('is-active', active);
        btn.setAttribute('aria-pressed', active ? 'true' : 'false');
      });
      if (countEl) {
        countEl.textContent = 'Показано проектов: ' + visible;
      }
    }

    buttons.forEach(function (btn) {
      btn.addEventListener('click', function () {
        applyFilter(btn.getAttribute('data-filter') || 'all');
      });
    });

    applyFilter('all');
  }

  /* ========================================================================
     Motion Polish: Staggered Reveal, Animated Counters & Spotlight
     ======================================================================== */

  function initRevealAndMotion() {
    var els = document.querySelectorAll('.reveal');
    var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (els.length) {
      els.forEach(function (el, idx) {
        el.style.setProperty('--reveal-delay', ((idx % 4) * 55) + 'ms');
      });

      if (reduced || !('IntersectionObserver' in window)) {
        els.forEach(function (el) {
          el.classList.add('is-visible');
        });
      } else {
        var observer = new IntersectionObserver(function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              entry.target.classList.add('is-visible');
              observer.unobserve(entry.target);
            }
          });
        }, { threshold: 0.06, rootMargin: '0px 0px -24px 0px' });

        els.forEach(function (el) {
          observer.observe(el);
        });
      }
    }

    if (!reduced && window.matchMedia && window.matchMedia('(hover: hover)').matches) {
      document.querySelectorAll('.service-card, .case-card, .tech-card').forEach(function (card) {
        card.addEventListener('pointermove', function (e) {
          var rect = card.getBoundingClientRect();
          card.style.setProperty('--mx', (e.clientX - rect.left) + 'px');
          card.style.setProperty('--my', (e.clientY - rect.top) + 'px');
        });
      });
    }
  }

  function initCounters() {
    var counters = document.querySelectorAll('[data-count-to]');
    if (!counters.length) return;
    var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced || !('IntersectionObserver' in window)) return;

    function animateValue(el) {
      var target = Number(el.getAttribute('data-count-to'));
      var suffix = el.getAttribute('data-count-suffix') || '';
      var spacer = el.getAttribute('data-count-space') === 'true';
      if (!target || isNaN(target)) return;

      var startTime = performance.now();
      var duration = 900;

      function tick(now) {
        var progress = Math.min(1, (now - startTime) / duration);
        var eased = 1 - Math.pow(1 - progress, 3);
        var val = Math.round(target * eased);
        var formatted = spacer ? val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ') : String(val);
        el.textContent = formatted + suffix;
        if (progress < 1) {
          requestAnimationFrame(tick);
        }
      }
      requestAnimationFrame(tick);
    }

    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateValue(entry.target);
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.35 });

    counters.forEach(function (el) {
      obs.observe(el);
    });
  }

  function initProcessSteps() {
    var steps = document.querySelectorAll('.step-card[data-step-detail]');
    var output = document.getElementById('step-detail-output');
    if (!steps.length || !output) return;

    steps.forEach(function (card) {
      card.addEventListener('click', function () {
        steps.forEach(function (c) { c.classList.remove('is-active'); });
        card.classList.add('is-active');
        output.textContent = card.getAttribute('data-step-detail') || '';
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    hydrateContacts();
    initPreferences();
    initStudioOverlays();
    initMobileNav();
    initHeroSwitcher();
    initPortalPreview();
    initCabinetPortal();
    initCopyButtons();
    initLeadForm();
    initReviewCarousel();
    initProjectFilters();
    initRevealAndMotion();
    initCounters();
    initProcessSteps();
  });
})();
